<template>
  <div>
    <router-view class="view">
    </router-view>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="less">
// @import './assets/css/var.less';
@import './assets/css/common.less';
html,
body {
  padding: 0;
  margin: 0;
}
</style>


