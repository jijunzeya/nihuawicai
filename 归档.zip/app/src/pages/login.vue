<template>
    <div class="main">
        <div class="header">头部</div>
        <div class="content">
            <span>这是span</span>
            这是内容</div>
    
        <div class="footer">Footer</div>
    
    </div>
</template>
<script>
export default {

}
</script>
<style lang="less" scoped>
.main {
    display: flex;
    flex-direction: column;
    height: 100vh; // position: absolute;
    .header {
        height: 70px; // width: 100%;
        background: #ff00ff; // position: fixed;
        // z-index: 1;
    }
    .content {
        // position: absolute;
        // width: 100%;
        background: #ffff00; // 
        // height: 100%;
        // top: 70px;
        // bottom: 70px;
        flex: 1; // overflow: auto;
        span {
            width: 100px;
            height: 100px;
        }
    }
    .footer {
        height: 70px; // width: 100%; // 
        // bottom: 0;
        // position: fixed;
        background: #00ff00; // 
        // z-index: 1;
    }
}
</style>
